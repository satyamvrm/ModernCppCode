#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType{
    CAB,
    BUS,
    BIKE
};

#endif // VEHICLETYPE_H
