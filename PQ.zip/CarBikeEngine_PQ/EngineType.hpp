#ifndef ENGINETYPE_HPP
#define ENGINETYPE_HPP

enum class EngineType {
    ICE,
    EV
};

#endif // ENGINETYPE_HPP
