#ifndef BIKETYPE_HPP
#define BIKETYPE_HPP

enum class BikeType {
    CLASSIC,
    LUXURY,
    SPORTS
};

#endif // BIKETYPE_HPP
