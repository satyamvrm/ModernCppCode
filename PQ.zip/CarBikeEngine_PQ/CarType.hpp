#ifndef CARTYPE_HPP
#define CARTYPE_HPP

enum class CarType {
    HATCHBACK,
    SEDAN,
    SUV
};

#endif // CARTYPE_HPP
