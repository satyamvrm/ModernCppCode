#include <unordered_map>
#include<vector>
#include<iostream>
#include<array>

int main(){

    std::unordered_map<int,std::string>map;
    map.emplace(1,"Aditya");
    for(auto &[key,value]:map){
        std::cout<<key<<value;
        
    }
    
}