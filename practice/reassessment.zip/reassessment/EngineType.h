#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType
{
    PETROL,
    DIESEL
};

#endif // ENGINETYPE_H
