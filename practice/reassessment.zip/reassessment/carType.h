#ifndef CARTYPE_H
#define CARTYPE_H

enum class CarType{

SUV, SEDAN, HATCHBACK

};

#endif // CARTYPE_H
