#include "Functionalities.h"
#include <variant>

void CreateObjects(FunctionConatiner &data)
{
    data.push_back(new Engine(EngineType::DIESEL, 100, 1900));
    data.push_back(new Engine(EngineType::PETROL, 990, 9000));
    data.push_back(new Engine(EngineType::DIESEL, 200, 8000));
    data.push_back(new Engine(EngineType::DIESEL, 12, 21));
}

FnType avgHP = [](FunctionConatiner &data)
{
    int sum{0};
    int i = 0;
    for (auto vec : data)
    {
        if (std::holds_alternative<Engine *>)
        {
            Engine *e = std::get<Engine*>(vec);
            sum += e->hp();
            i++;
        }
    }
    return (sum / i);
};

FnType avgCC = [](FunctionConatiner &data)
{
    int sum{0};
    int i = 0;
    for (Vtype vec : data)
    {
        if (std::holds_alternative<Engine*>)
        {
            Engine *e = std::get<Engine*>(vec);
            sum += e->cc();
        }
    }
    return (sum / i);
};