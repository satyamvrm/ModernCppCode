#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include "Car.h"
#include "Engine.h"
#include <variant>
#include <vector>

using Vtype = std::variant<Car*, Engine*>;
using FunctionConatiner = std::vector<Vtype>;

using FnType = std::function<int(FunctionConatiner &)>;

void CreateObjects(FunctionConatiner &data);

extern FnType avgHP;
extern FnType maxCC;

#endif // FUNCTIONALITIES_H
