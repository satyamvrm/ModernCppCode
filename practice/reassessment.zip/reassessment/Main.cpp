#include "Functionalities.h"
#include <functional>
#include <iostream>
#include <future>

int main()
{
    FunctionConatiner data;
    CreateObjects(data);
    auto binded_obj = std::bind(&Car::getFirstInstance ,std::placeholders::_1,std::placeholders::_2, CarType::SEDAN);

    std::promise<int> pr;
    std::future<int> ft = pr.get_future();
    std::future<Car*> val = std::async(binded_obj, "AK", std::ref(ft));

    int n;
    std::cout<<"Enter n: ";
    std::cin>>n;
    pr.set_value(n);
    std::cout<<*val.get();
    
    int ans=avgHP(data);
    std::cout<<ans;
    
}