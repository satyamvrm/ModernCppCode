#ifndef BATTERY_TYPE_H
#define BATTERY_TYPE_H

enum class BatteryType{
    LI_ION,
    NI_CAD,
    OTHER
};

#endif // BATTERY_TYPE_H
