#ifndef ENGINE_TYPE_H
#define ENGINE_TYPE_H

enum class EngineType{
    PETROL,
    DIESEL
};

#endif // ENGINE_TYPE_H
