#ifndef E_POWER_TYPE_H
#define E_POWER_TYPE_H

enum class EPowerType{
    HYBRID,
    ELECTIC
};

#endif // E_POWER_TYPE_H
